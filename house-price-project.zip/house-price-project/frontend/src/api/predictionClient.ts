import type { ApiErrorBody, PredictionRequest, PredictionResponse } from "../types/prediction";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export class PredictionApiError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PredictionApiError";
  }
}

function extractErrorMessage(body: ApiErrorBody | undefined): string {
  if (!body || !body.detail) {
    return "Something went wrong while contacting the prediction service.";
  }
  if (typeof body.detail === "string") {
    return body.detail;
  }
  return body.detail.map((d) => `${d.loc[d.loc.length - 1]}: ${d.msg}`).join(", ");
}

export async function fetchLocations(): Promise<string[]> {
  const response = await fetch("/locations.json");
  if (!response.ok) {
    return [];
  }
  return response.json();
}

export async function predictPrice(payload: PredictionRequest): Promise<PredictionResponse> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new PredictionApiError(
      "Could not reach the prediction API. Is the backend running on " + API_BASE_URL + "?"
    );
  }

  if (!response.ok) {
    let body: ApiErrorBody | undefined;
    try {
      body = await response.json();
    } catch {
      body = undefined;
    }
    throw new PredictionApiError(extractErrorMessage(body));
  }

  return response.json();
}

export async function checkHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/health`);
    return response.ok;
  } catch {
    return false;
  }
}
