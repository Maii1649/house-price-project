import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchLocations, predictPrice, PredictionApiError } from "../api/predictionClient";
import type { PredictionRequest } from "../types/prediction";

const STATUS_OPTIONS = ["Ready to Move", "Under Construction"] as const;
const FURNISHING_OPTIONS = ["Unfurnished", "Semi-Furnished", "Furnished"] as const;
const TRANSACTION_OPTIONS = ["Resale", "New Property"] as const;
const OWNERSHIP_OPTIONS = ["Freehold", "Leasehold", "Co-operative society", "Power of Attorney"];

type FormState = {
  location: string;
  area_sqft: string;
  floor_num: string;
  bathroom: string;
  balcony: string;
  car_parking: string;
  status: string;
  furnishing: string;
  transaction: string;
  ownership: string;
};

const INITIAL_STATE: FormState = {
  location: "",
  area_sqft: "",
  floor_num: "0",
  bathroom: "1",
  balcony: "0",
  car_parking: "0",
  status: STATUS_OPTIONS[0],
  furnishing: FURNISHING_OPTIONS[0],
  transaction: TRANSACTION_OPTIONS[0],
  ownership: OWNERSHIP_OPTIONS[0],
};

export default function PredictionForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormState>(INITIAL_STATE);
  const [locations, setLocations] = useState<string[]>([]);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchLocations().then((locs) => {
      setLocations(locs);
      if (locs.length > 0) {
        setForm((prev) => ({ ...prev, location: prev.location || locs[0] }));
      }
    });
  }, []);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function validate(current: FormState): Partial<Record<keyof FormState, string>> {
    const next: Partial<Record<keyof FormState, string>> = {};

    if (!current.location.trim()) next.location = "Pick a location.";

    const area = Number(current.area_sqft);
    if (!current.area_sqft) next.area_sqft = "Area is required.";
    else if (Number.isNaN(area) || area <= 0) next.area_sqft = "Area must be a number greater than 0.";

    for (const key of ["floor_num", "bathroom", "balcony", "car_parking"] as const) {
      const value = current[key];
      if (value === "" || Number.isNaN(Number(value))) {
        next[key] = "Enter a whole number.";
      }
    }

    if (!current.status) next.status = "Required.";
    if (!current.furnishing) next.furnishing = "Required.";
    if (!current.transaction) next.transaction = "Required.";
    if (!current.ownership) next.ownership = "Required.";

    return next;
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setSubmitError(null);

    const validationErrors = validate(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const payload: PredictionRequest = {
      location: form.location,
      area_sqft: Number(form.area_sqft),
      floor_num: Number(form.floor_num),
      bathroom: Number(form.bathroom),
      balcony: Number(form.balcony),
      car_parking: Number(form.car_parking),
      status: form.status as PredictionRequest["status"],
      furnishing: form.furnishing as PredictionRequest["furnishing"],
      transaction: form.transaction as PredictionRequest["transaction"],
      ownership: form.ownership,
    };

    setIsLoading(true);
    try {
      const result = await predictPrice(payload);
      navigate("/result", { state: { prediction: result, request: payload } });
    } catch (err) {
      const message =
        err instanceof PredictionApiError ? err.message : "Unexpected error. Please try again.";
      setSubmitError(message);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <form className="estimate-form" onSubmit={handleSubmit} noValidate>
      <div className="field-grid">
        <label className="field">
          <span className="field-label">Location</span>
          {locations.length > 0 ? (
            <select
              value={form.location}
              onChange={(e) => update("location", e.target.value)}
              aria-invalid={Boolean(errors.location)}
            >
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          ) : (
            <input
              type="text"
              placeholder="e.g. thane"
              value={form.location}
              onChange={(e) => update("location", e.target.value)}
              aria-invalid={Boolean(errors.location)}
            />
          )}
          {errors.location && <span className="field-error">{errors.location}</span>}
        </label>

        <label className="field">
          <span className="field-label">Carpet / Super area (sqft)</span>
          <input
            type="number"
            min={1}
            step="1"
            placeholder="650"
            value={form.area_sqft}
            onChange={(e) => update("area_sqft", e.target.value)}
            aria-invalid={Boolean(errors.area_sqft)}
          />
          {errors.area_sqft && <span className="field-error">{errors.area_sqft}</span>}
        </label>

        <label className="field">
          <span className="field-label">Floor</span>
          <input
            type="number"
            step="1"
            value={form.floor_num}
            onChange={(e) => update("floor_num", e.target.value)}
            aria-invalid={Boolean(errors.floor_num)}
          />
          {errors.floor_num && <span className="field-error">{errors.floor_num}</span>}
        </label>

        <label className="field">
          <span className="field-label">Bathrooms</span>
          <input
            type="number"
            min={0}
            step="1"
            value={form.bathroom}
            onChange={(e) => update("bathroom", e.target.value)}
            aria-invalid={Boolean(errors.bathroom)}
          />
          {errors.bathroom && <span className="field-error">{errors.bathroom}</span>}
        </label>

        <label className="field">
          <span className="field-label">Balconies</span>
          <input
            type="number"
            min={0}
            step="1"
            value={form.balcony}
            onChange={(e) => update("balcony", e.target.value)}
            aria-invalid={Boolean(errors.balcony)}
          />
          {errors.balcony && <span className="field-error">{errors.balcony}</span>}
        </label>

        <label className="field">
          <span className="field-label">Car parking spots</span>
          <input
            type="number"
            min={0}
            step="1"
            value={form.car_parking}
            onChange={(e) => update("car_parking", e.target.value)}
            aria-invalid={Boolean(errors.car_parking)}
          />
          {errors.car_parking && <span className="field-error">{errors.car_parking}</span>}
        </label>

        <label className="field">
          <span className="field-label">Status</span>
          <select value={form.status} onChange={(e) => update("status", e.target.value)}>
            {STATUS_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="field-label">Furnishing</span>
          <select value={form.furnishing} onChange={(e) => update("furnishing", e.target.value)}>
            {FURNISHING_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="field-label">Transaction</span>
          <select value={form.transaction} onChange={(e) => update("transaction", e.target.value)}>
            {TRANSACTION_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="field-label">Ownership</span>
          <select value={form.ownership} onChange={(e) => update("ownership", e.target.value)}>
            {OWNERSHIP_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </label>
      </div>

      {submitError && <p className="form-alert">{submitError}</p>}

      <button type="submit" className="primary-button" disabled={isLoading}>
        {isLoading ? "Estimating…" : "Estimate price"}
      </button>
    </form>
  );
}
