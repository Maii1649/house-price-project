// Mirrors backend/app/schemas/prediction.py — keep these in sync.

export type FurnishingStatus = "Furnished" | "Semi-Furnished" | "Unfurnished";
export type TransactionType = "New Property" | "Resale";
export type PropertyStatus = "Ready to Move" | "Under Construction";

export interface PredictionRequest {
  location: string;
  area_sqft: number;
  floor_num: number;
  bathroom: number;
  balcony: number;
  car_parking: number;
  status: PropertyStatus;
  furnishing: FurnishingStatus;
  transaction: TransactionType;
  ownership: string;
}

export interface PredictionResponse {
  predicted_price: number;
}

export interface ApiErrorDetail {
  loc: (string | number)[];
  msg: string;
  type: string;
}

export interface ApiErrorBody {
  detail: string | ApiErrorDetail[];
}
