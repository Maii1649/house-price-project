import PredictionForm from "../components/PredictionForm";

export default function HomePage() {
  return (
    <div className="page page-home">
      <header className="hero">
        <p className="eyebrow">Ghar · House price estimator</p>
        <h1>What's this property actually worth?</h1>
        <p className="hero-sub">
          Enter the details below and a Random Forest model — trained on real Indian
          property listings — will estimate a market price in seconds.
        </p>
      </header>

      <section className="panel">
        <PredictionForm />
      </section>

      <p className="hero-footnote">
        Estimates are model-generated from historical listings and are not a formal
        valuation.
      </p>
    </div>
  );
}
