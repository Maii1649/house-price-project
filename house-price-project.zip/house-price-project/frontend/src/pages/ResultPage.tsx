import { Link, useLocation, Navigate } from "react-router-dom";
import type { PredictionRequest, PredictionResponse } from "../types/prediction";

interface ResultLocationState {
  prediction: PredictionResponse;
  request: PredictionRequest;
}

function formatIndianPrice(value: number): string {
  if (value >= 1e7) return `₹ ${(value / 1e7).toFixed(2)} Cr`;
  if (value >= 1e5) return `₹ ${(value / 1e5).toFixed(2)} Lac`;
  return `₹ ${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;
}

export default function ResultPage() {
  const location = useLocation();
  const state = location.state as ResultLocationState | null;

  if (!state?.prediction) {
    return <Navigate to="/" replace />;
  }

  const { prediction, request } = state;

  return (
    <div className="page page-result">
      <p className="eyebrow">Estimate ready</p>
      <p className="result-price">{formatIndianPrice(prediction.predicted_price)}</p>
      <p className="result-exact">
        {Math.round(prediction.predicted_price).toLocaleString("en-IN")} rupees (approx.)
      </p>

      <div className="summary-card">
        <h2>Property summary</h2>
        <dl className="summary-grid">
          <div>
            <dt>Location</dt>
            <dd>{request.location}</dd>
          </div>
          <div>
            <dt>Area</dt>
            <dd>{request.area_sqft} sqft</dd>
          </div>
          <div>
            <dt>Floor</dt>
            <dd>{request.floor_num}</dd>
          </div>
          <div>
            <dt>Bathrooms</dt>
            <dd>{request.bathroom}</dd>
          </div>
          <div>
            <dt>Balconies</dt>
            <dd>{request.balcony}</dd>
          </div>
          <div>
            <dt>Parking</dt>
            <dd>{request.car_parking}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd>{request.status}</dd>
          </div>
          <div>
            <dt>Furnishing</dt>
            <dd>{request.furnishing}</dd>
          </div>
          <div>
            <dt>Transaction</dt>
            <dd>{request.transaction}</dd>
          </div>
          <div>
            <dt>Ownership</dt>
            <dd>{request.ownership}</dd>
          </div>
        </dl>
      </div>

      <Link to="/" className="primary-button link-button">
        Estimate another property
      </Link>
    </div>
  );
}
