import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="page page-notfound">
      <p className="eyebrow">404</p>
      <h1>This plot hasn't been surveyed.</h1>
      <p className="hero-sub">The page you're looking for doesn't exist.</p>
      <Link to="/" className="primary-button link-button">
        Back to the estimator
      </Link>
    </div>
  );
}
