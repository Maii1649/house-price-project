"""Tests for the /health and /predict endpoints.

Run with (from the backend/ folder):
    pytest
"""

from fastapi.testclient import TestClient

from app.main import create_app
from app.services.inference import init_inference_service


def build_test_client(model_path: str, locations_path: str) -> TestClient:
    """Build a FastAPI TestClient wired to a dummy model (bypassing the lifespan)."""
    app = create_app()
    init_inference_service(model_path, locations_path)
    return TestClient(app)


def test_health_ok(dummy_model_dir):
    model_path, locations_path = dummy_model_dir
    client = build_test_client(model_path, locations_path)

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_predict_happy_path(dummy_model_dir):
    model_path, locations_path = dummy_model_dir
    client = build_test_client(model_path, locations_path)

    payload = {
        "location": "thane",
        "area_sqft": 650,
        "floor_num": 3,
        "bathroom": 2,
        "balcony": 1,
        "car_parking": 1,
        "status": "Ready to Move",
        "furnishing": "Semi-Furnished",
        "transaction": "Resale",
        "ownership": "Freehold",
    }

    response = client.post("/predict", json=payload)

    assert response.status_code == 200
    body = response.json()
    assert "predicted_price" in body
    assert isinstance(body["predicted_price"], float)
    assert body["predicted_price"] > 0


def test_predict_invalid_input_returns_422(dummy_model_dir):
    model_path, locations_path = dummy_model_dir
    client = build_test_client(model_path, locations_path)

    # area_sqft must be > 0, and several required fields are missing here.
    payload = {
        "location": "thane",
        "area_sqft": -10,
    }

    response = client.post("/predict", json=payload)

    assert response.status_code == 422


def test_predict_unknown_location_falls_back_to_other(dummy_model_dir):
    model_path, locations_path = dummy_model_dir
    client = build_test_client(model_path, locations_path)

    payload = {
        "location": "some-city-not-in-training-data",
        "area_sqft": 800,
        "floor_num": 1,
        "bathroom": 2,
        "balcony": 1,
        "car_parking": 0,
        "status": "Ready to Move",
        "furnishing": "Furnished",
        "transaction": "New Property",
        "ownership": "Freehold",
    }

    response = client.post("/predict", json=payload)

    assert response.status_code == 200
