"""Shared pytest fixtures.

Tests build a tiny, fast dummy Pipeline with the same feature schema as the real
model, so the test-suite is self-contained and does not depend on the (large)
trained house_price.pkl being present.
"""

import json

import joblib
import numpy as np
import pandas as pd
import pytest
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from app.services.preprocessing import CATEGORICAL_FEATURES, NUMERIC_FEATURES


@pytest.fixture(scope="session")
def dummy_model_dir(tmp_path_factory):
    model_dir = tmp_path_factory.mktemp("models")

    n = 50
    rng = np.random.default_rng(42)
    df = pd.DataFrame({
        "area_sqft": rng.uniform(300, 2000, n),
        "floor_num": rng.integers(0, 20, n),
        "bathroom": rng.integers(1, 4, n),
        "balcony": rng.integers(0, 3, n),
        "car_parking": rng.integers(0, 2, n),
        "location_grouped": rng.choice(["thane", "mumbai", "other"], n),
        "status": rng.choice(["Ready to Move", "Under Construction"], n),
        "transaction": rng.choice(["New Property", "Resale"], n),
        "furnishing": rng.choice(["Furnished", "Semi-Furnished", "Unfurnished"], n),
        "ownership": rng.choice(["Freehold", "Leasehold"], n),
    })
    y = df["area_sqft"] * 5000 + rng.normal(0, 10000, n)

    preprocessor = ColumnTransformer([
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), NUMERIC_FEATURES),
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), CATEGORICAL_FEATURES),
    ])

    model = Pipeline([
        ("prep", preprocessor),
        ("reg", RandomForestRegressor(n_estimators=10, random_state=42)),
    ])
    model.fit(df, y)

    model_path = model_dir / "house_price.pkl"
    joblib.dump(model, model_path)

    locations_path = model_dir / "locations.json"
    with open(locations_path, "w") as f:
        json.dump(["thane", "mumbai"], f)

    return str(model_path), str(locations_path)
