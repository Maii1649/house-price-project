"""GET /health and POST /predict routes."""

import logging

from fastapi import APIRouter, HTTPException

from app.schemas.prediction import HealthResponse, PredictionRequest, PredictionResponse
from app.services.inference import get_inference_service

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["health"])
def health() -> HealthResponse:
    """Simple liveness/readiness probe."""
    service = get_inference_service()
    if not service.is_ready():
        raise HTTPException(status_code=503, detail="Model is not loaded")
    return HealthResponse(status="ok")


@router.post("/predict", response_model=PredictionResponse, tags=["prediction"])
def predict(request: PredictionRequest) -> PredictionResponse:
    """Predict a house price from property details."""
    service = get_inference_service()
    try:
        predicted_price = service.predict(request)
    except Exception as exc:  # noqa: BLE001 - surface a clean 500 instead of a stack trace
        logger.exception("Prediction failed")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {exc}") from exc

    return PredictionResponse(predicted_price=predicted_price)
