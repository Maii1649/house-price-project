"""Application settings, loaded from environment variables / .env file."""

from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central place for all configurable values.

    Values are read from environment variables first, falling back to the
    defaults below, and can be overridden by a `.env` file in the backend/
    working directory (see `.env.example`).
    """

    app_name: str = "House Price Prediction API"
    app_version: str = "1.0.0"

    model_path: str = "models/house_price.pkl"
    locations_path: str = "models/locations.json"

    cors_origins: str = "http://localhost:5173"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @property
    def cors_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    """Cached settings instance (avoids re-reading the environment every call)."""
    return Settings()
