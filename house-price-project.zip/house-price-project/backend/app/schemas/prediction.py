"""Request / response models for the /predict endpoint.

These field names and types must match the feature names used when training the
model in `notebooks/house_price_model.ipynb` (NUMERIC_FEATURES + CATEGORICAL_FEATURES).
"""

from pydantic import BaseModel, Field, field_validator


class PredictionRequest(BaseModel):
    location: str = Field(..., description="Grouped location name, e.g. 'thane' or 'other'")
    area_sqft: float = Field(..., gt=0, description="Carpet/Super area in square feet")
    floor_num: int = Field(..., description="Floor number (0 = ground, -1 = basement)")
    bathroom: int = Field(..., ge=0, description="Number of bathrooms")
    balcony: int = Field(..., ge=0, description="Number of balconies")
    car_parking: int = Field(0, ge=0, description="Number of car parking spots")
    status: str = Field(..., description="'Ready to Move' | 'Under Construction'")
    furnishing: str = Field(..., description="'Furnished' | 'Semi-Furnished' | 'Unfurnished'")
    transaction: str = Field(..., description="'New Property' | 'Resale'")
    ownership: str = Field(..., description="Ownership type, e.g. 'Freehold'")

    @field_validator("area_sqft")
    @classmethod
    def area_must_be_positive(cls, value: float) -> float:
        if value <= 0:
            raise ValueError("area_sqft must be greater than 0")
        return value

    model_config = {
        "json_schema_extra": {
            "example": {
                "location": "thane",
                "area_sqft": 650,
                "floor_num": 3,
                "bathroom": 2,
                "balcony": 1,
                "car_parking": 1,
                "status": "Ready to Move",
                "furnishing": "Semi-Furnished",
                "transaction": "Resale",
                "ownership": "Freehold",
            }
        }
    }


class PredictionResponse(BaseModel):
    predicted_price: float


class HealthResponse(BaseModel):
    status: str = "ok"
