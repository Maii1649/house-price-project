"""Turn a validated PredictionRequest into the one-row DataFrame the pipeline expects.

The exported model is a full scikit-learn Pipeline (imputers + scaler + one-hot
encoder + regressor), so no manual encoding happens here — we only need to build a
DataFrame with exactly the column names used during training.
"""

import pandas as pd

from app.schemas.prediction import PredictionRequest

NUMERIC_FEATURES = ["area_sqft", "floor_num", "bathroom", "balcony", "car_parking"]
CATEGORICAL_FEATURES = ["location_grouped", "status", "transaction", "furnishing", "ownership"]
FEATURE_ORDER = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def request_to_dataframe(request: PredictionRequest, allowed_locations: set[str]) -> pd.DataFrame:
    """Build a single-row DataFrame matching the training-time schema.

    Unknown locations are mapped to "other", exactly like the notebook does for any
    location outside the top-N most frequent ones.
    """
    location_grouped = request.location if request.location in allowed_locations else "other"

    row = {
        "area_sqft": request.area_sqft,
        "floor_num": request.floor_num,
        "bathroom": request.bathroom,
        "balcony": request.balcony,
        "car_parking": request.car_parking,
        "location_grouped": location_grouped,
        "status": request.status,
        "transaction": request.transaction,
        "furnishing": request.furnishing,
        "ownership": request.ownership,
    }

    return pd.DataFrame([row], columns=FEATURE_ORDER)
