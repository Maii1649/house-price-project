"""Load the exported Pipeline + locations list once, and run predictions."""

import json
import logging
from pathlib import Path
from typing import Optional

import joblib

from app.schemas.prediction import PredictionRequest
from app.services.preprocessing import request_to_dataframe

logger = logging.getLogger(__name__)


class InferenceService:
    """Wraps the loaded model + allowed-locations set.

    Instantiated once at application startup (see `app.main` lifespan) and reused
    for every request, so the (relatively expensive) `joblib.load` only happens once.
    """

    def __init__(self, model_path: str, locations_path: str) -> None:
        self.model_path = Path(model_path)
        self.locations_path = Path(locations_path)
        self.model = None
        self.allowed_locations: set[str] = set()

    def load(self) -> None:
        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Model file not found at '{self.model_path}'. "
                "Copy house_price.pkl from the notebook into backend/models/."
            )
        logger.info("Loading model from %s", self.model_path)
        self.model = joblib.load(self.model_path)

        if self.locations_path.exists():
            with open(self.locations_path, "r", encoding="utf-8") as f:
                self.allowed_locations = set(json.load(f))
            logger.info("Loaded %d allowed locations", len(self.allowed_locations))
        else:
            logger.warning(
                "Locations file not found at '%s'. All locations will be treated as 'other'.",
                self.locations_path,
            )

    def is_ready(self) -> bool:
        return self.model is not None

    def predict(self, request: PredictionRequest) -> float:
        if self.model is None:
            raise RuntimeError("Model is not loaded yet.")
        df = request_to_dataframe(request, self.allowed_locations)
        prediction = self.model.predict(df)[0]
        return float(prediction)


# Singleton instance, populated during the FastAPI lifespan startup event.
inference_service: Optional[InferenceService] = None


def get_inference_service() -> InferenceService:
    if inference_service is None:
        raise RuntimeError("Inference service has not been initialised yet.")
    return inference_service


def init_inference_service(model_path: str, locations_path: str) -> InferenceService:
    global inference_service
    inference_service = InferenceService(model_path, locations_path)
    inference_service.load()
    return inference_service
